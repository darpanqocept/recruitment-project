<?php
include_once('header.php');
?>

<div class="content">
  <div class="container">
    <div class="vd_navbar vd_nav-width vd_navbar-email vd_bg-black-80 vd_navbar-left vd_navbar-style-2 ">
	<div class="navbar-tabs-menu clearfix">
			<span class="expand-menu" data-action="expand-navbar-tabs-menu">
            	<span class="menu-icon menu-icon-left">
            		<i class="fa fa-ellipsis-h"></i>
                    <span class="badge vd_bg-red">
                        20
                    </span>                    
                </span>
            	<span class="menu-icon menu-icon-right">
            		<i class="fa fa-ellipsis-h"></i>
                    <span class="badge vd_bg-red">
                        20
                    </span>                    
                </span>                
            </span>  
            <div class="menu-container">               
        		 <div class="navbar-search-wrapper">
    <div class="navbar-search vd_bg-black-30">
        <span class="append-icon"><i class="fa fa-search"></i></span>
        <input type="text" placeholder="Search" class="vd_menu-search-text no-bg no-bd vd_white width-70" name="search">
        <div class="pull-right search-config">                                
            <a  data-toggle="dropdown" href="javascript:void(0);" class="dropdown-toggle" ><span class="prepend-icon vd_grey"><i class="fa fa-cog"></i></span></a>
            <ul role="menu" class="dropdown-menu">
                <li><a href="#">Action</a></li>
                <li><a href="#">Another action</a></li>
                <li><a href="#">Something else here</a></li>
                <li class="divider"></li>
                <li><a href="#">Separated link</a></li>
              </ul>                                    
        </div>
    </div>
</div>  
            </div>        
                                                 
    </div>
	<div class="navbar-menu clearfix">
    	<h3 class="menu-title hide-nav-medium hide-nav-small"><a href="email-compose.html" class="btn vd_btn vd_bg-red"><span class="append-icon"><i class="icon-feather"></i></span>Compose Email</a></h3>
        <div class="vd_menu">
        	<ul>
	<li class="line vd_bd-grey">
    </li>
 	<li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon entypo-icon"><i class="icon-mail"></i></span> 
            <span class="menu-text">Inbox</span>  
            <span class="menu-badge"><span class="badge vd_bg-red">78+</span></span>
       	</a> 
    </li> 
    <li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon"><i class="fa fa-archive"></i></span> 
            <span class="menu-text">Drafts</span>  
            <span class="menu-badge"><span class="badge vd_bg-red">5</span></span>            
       	</a>
    </li>          
    <li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon entypo-icon"><i class="icon-paperplane"></i></span> 
            <span class="menu-text">Sent</span>  
       	</a>
    </li>          
    <li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon"><i class="fa fa-shield"></i></span> 
            <span class="menu-text">Spam</span>
            <span class="menu-badge"><span class="badge vd_bg-red">99+</span></span>               
       	</a>
    </li>          
    <li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon entypo-icon"><i class="icon-trash"></i></span> 
            <span class="menu-text">Trash</span>  
       	</a>
    </li>          
    <li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon entypo-icon"><i class="icon-folder"></i></span> 
            <span class="menu-text">Folders</span>  
       	</a>
    </li>             
	<li class="line vd_bd-grey">
    </li>
    <li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon entypo-icon"><i class="icon-user"></i></span> 
            <span class="menu-text">Messenger</span>  
       	</a>
    </li>
    <li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon entypo-icon"><i class="icon-calendar"></i></span> 
            <span class="menu-text">Calendar</span>  
       	</a>
    </li>  
    <li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon"><i class="glyphicon glyphicon-book"></i></span> 
            <span class="menu-text">Contacts</span>  
       	</a>
    </li>  
    <li>
    	<a href="javascript:void(0);">
        	<span class="menu-icon"><i class="glyphicon glyphicon-file"></i></span> 
            <span class="menu-text">Notepad</span>  
       	</a>
    </li> 
	<li class="line vd_bd-grey">
    </li>
    <li>
    	<a href="index-2.html">
        	<span class="menu-icon"><i class="fa fa-desktop"></i></span> 
            <span class="menu-text">Back to Home</span>  
       	</a>
    </li>                             
</ul>
<!-- Head menu search form ends -->         </div>  

            
    </div>






<?php
include_once('footer.php');
?>