<hr>
                          <div class="form-group"  >
                            <label class="col-sm-3 control-label">Experience</label>
                            <div class="col-sm-9 controls">
                              <div class="row mgbt-xs-0">
                                <div class="col-xs-5">

                                  <input type="email"  placeholder="Experience Title">

                                </div>
                                <!-- col-xs-12 -->
                                <div class="col-xs-4">
                                 <input type="email"  placeholder="Year">

                               </div>
                               <div class="col-xs-2">
                                <div class="btn-action">
                                  <button data-toggle="dropdown" class="btn btn-icon dropdown-toggle vd_bg-yellow vd_white" type="button"><i class="fa fa-globe fa-fw"></i></button>
                                  <ul class="dropdown-menu pull-right">
                                    <li><a href="#"><i class="fa fa-globe fa-fw"></i> Public</a></li>
                                    <li><a href="#"><i class="fa fa-user fa-fw"></i> Friends</a></li>
                                    <li><a href="#"><i class="fa fa-lock fa-fw"></i> Only Me</a></li>
                                  </ul>
                                </div>
                                <!-- btn-action col-sm-10 --> 
                              </div>
                            </div>
                            <!-- row --> 
                          </div>
                          <!-- col-sm-10 --> 
                        </div>




                        <div class="form-group"  >
                          <label class="col-sm-3 control-label">Company</label>
                          <div class="col-sm-9 controls">
                            <div class="row mgbt-xs-0">
                              <div class="col-xs-8">
                                <input type="text"  placeholder="Company Name">
                              </div>
                              <!-- col-xs-12 -->
                              <div class="col-xs-3">

                                <a class="btn vd_btn  vd_bg-blue" href="javascript:void(0);"><i class="fa fa-cloud-upload append-icon"></i> Upload</a>

                              </div>
                                <!-- <div class="col-xs-2">
                                  <div class="btn-action">
                                    <button data-toggle="dropdown" class="btn btn-icon dropdown-toggle vd_bg-yellow vd_white" type="button"><i class="fa fa-globe fa-fw"></i></button>
                                    <ul class="dropdown-menu pull-right">
                                      <li><a href="#"><i class="fa fa-globe fa-fw"></i> Public</a></li>
                                      <li><a href="#"><i class="fa fa-user fa-fw"></i> Friends</a></li>
                                      <li><a href="#"><i class="fa fa-lock fa-fw"></i> Only Me</a></li>
                                    </ul>
                                  </div>
                                  
                                </div> -->
                              </div>
                              <!-- row --> 
                            </div>
                            <!-- col-sm-10 --> 
                          </div>


                          <div class="form-group"  >
                            <label class="col-sm-3 control-label">Experience</label>
                            <div class="col-sm-9 controls">
                              <div class="row mgbt-xs-0">
                                <div class="col-xs-5">

                                  <input type="email"  placeholder="Starting Date">

                                </div>
                                <!-- col-xs-12 -->
                                <div class="col-xs-4">
                                 <input type="email"  placeholder="Ending Date">

                               </div>
                               <div class="col-xs-2">
                                <div class="btn-action">
                                  <button data-toggle="dropdown" class="btn btn-icon dropdown-toggle vd_bg-yellow vd_white" type="button"><i class="fa fa-globe fa-fw"></i></button>
                                  <ul class="dropdown-menu pull-right">
                                    <li><a href="#"><i class="fa fa-globe fa-fw"></i> Public</a></li>
                                    <li><a href="#"><i class="fa fa-user fa-fw"></i> Friends</a></li>
                                    <li><a href="#"><i class="fa fa-lock fa-fw"></i> Only Me</a></li>
                                  </ul>
                                </div>
                                <!-- btn-action col-sm-10 --> 
                              </div>
                            </div>
                            <!-- row --> 
                          </div>
                          <!-- col-sm-10 --> 
                        </div>

                        <div class="form-group"  >
                          <label class="col-sm-3 control-label">Discription</label>
                          <div class="col-sm-9 controls">
                            <div class="row mgbt-xs-0">
                              <div class="col-xs-9">

                                <input type="email"  placeholder="Experience Discription">

                              </div>
                              <!-- col-xs-12 -->

                              <div class="col-xs-2">
                                <div class="btn-action">
                                  <button data-toggle="dropdown" class="btn btn-icon dropdown-toggle vd_bg-yellow vd_white" type="button"><i class="fa fa-globe fa-fw"></i></button>
                                  <ul class="dropdown-menu pull-right">
                                    <li><a href="#"><i class="fa fa-globe fa-fw"></i> Public</a></li>
                                    <li><a href="#"><i class="fa fa-user fa-fw"></i> Friends</a></li>
                                    <li><a href="#"><i class="fa fa-lock fa-fw"></i> Only Me</a></li>
                                  </ul>
                                </div>
                                <!-- btn-action col-sm-10 --> 
                              </div>
                            </div>
                            <!-- row --> 
                          </div>
                          <!-- col-sm-10 --> 
                        </div>