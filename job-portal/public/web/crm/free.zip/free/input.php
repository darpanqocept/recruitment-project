<hr>

<div class="form-group"  >
  <label class="col-sm-3 control-label">Degree Detail</label>
  <div class="col-sm-9 controls">
    <div class="row mgbt-xs-0">
      <div class="col-xs-5">

        <select  id="degree_level_id" name="degree_level_id"><option value="" selected="selected">Select Degree Level</option><option value="1">Non-Matriculation</option><option value="2">Matriculation/O-Level</option><option value="3">Intermediate/A-Level</option><option value="4">Bachelors</option><option value="5">Masters</option><option value="6">MPhil/MS</option><option value="7">PHD/Doctorate</option><option value="8">Certification</option><option value="9">Diploma</option><option value="10">Short Course</option></select>

      </div>
      <!-- col-xs-12 -->
      <div class="col-xs-4">
        <select  id="degree_type_id" name="degree_type_id"><option value="" selected="selected">Select Degree Type</option></select>

      </div>
      <div class="col-xs-2">
        <div class="btn-action">
          <button data-toggle="dropdown" class="btn btn-icon dropdown-toggle vd_bg-yellow vd_white" type="button"><i class="fa fa-globe fa-fw"></i></button>
          <ul class="dropdown-menu pull-right">
            <li><a href="#"><i class="fa fa-globe fa-fw"></i> Public</a></li>
            <li><a href="#"><i class="fa fa-user fa-fw"></i> Friends</a></li>
            <li><a href="#"><i class="fa fa-lock fa-fw"></i> Only Me</a></li>
          </ul>
        </div>
        <!-- btn-action col-sm-10 --> 
      </div>
    </div>
    <!-- row --> 
  </div>
  <!-- col-sm-10 --> 
</div>



<div class="form-group"  >
  <label class="col-sm-3 control-label">Degree Title</label>
  <div class="col-sm-9 controls">
    <div class="row mgbt-xs-0">
      <div class="col-xs-8">
        <input type="text"  placeholder="Degree Title">
      </div>
      <!-- col-xs-12 -->
      <div class="col-xs-3">

        <a class="btn vd_btn  vd_bg-blue" href="javascript:void(0);"><i class="fa fa-cloud-upload append-icon"></i> Upload</a>

      </div>
                                <!-- <div class="col-xs-2">
                                  <div class="btn-action">
                                    <button data-toggle="dropdown" class="btn btn-icon dropdown-toggle vd_bg-yellow vd_white" type="button"><i class="fa fa-globe fa-fw"></i></button>
                                    <ul class="dropdown-menu pull-right">
                                      <li><a href="#"><i class="fa fa-globe fa-fw"></i> Public</a></li>
                                      <li><a href="#"><i class="fa fa-user fa-fw"></i> Friends</a></li>
                                      <li><a href="#"><i class="fa fa-lock fa-fw"></i> Only Me</a></li>
                                    </ul>
                                  </div>
                                  
                                </div> -->
                              </div>
                              <!-- row --> 
                            </div>
                            <!-- col-sm-10 --> 
                          </div>